package MyProject2;

import java.util.Random;

public class Word {
    public static void main(String[] args) {
        
        String[] word = {"BANANA", "APPLE", "GRAPE", "ABC"}; // 문제들 -> 메모장에서 가져와서 쓸 것!
        int rand = (int)(Math.random() * word.length); // 배열의 길이만큼 랜덤 수 생성

        // world[rand] == world 안에 있는 랜덤 단어
        String selectedWord = word[rand]; // 랜덤으로 선택된 단어
        StringBuilder displayedWord = new StringBuilder();

        // 각 문자마다 '_' 표시
        for (int i = 0; i < selectedWord.length(); i++) {
            displayedWord.append("_");  // 각 문자를 _로 표시
            if (i < selectedWord.length() - 1) {
                displayedWord.append(" ");  // 각 _ 사이에 공백 추가
            }
        }

        System.out.println("단어: " + displayedWord.toString()); // 단어를 _로 표시된 문자열로 출력
        
        
        int lengthWorld = selectedWord.length(); // 랜덤 단어의 길이
        System.out.println("랜덤 단어의 길이: " + lengthWorld); // 단어의 길이 출력
    }
}
