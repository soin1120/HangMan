package MyProject2;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class HangOutTest extends Frame implements ActionListener {
    
    StringBuilder sb = new StringBuilder();
    String[] word = {"BANANA", "APPLE", "GRAPE", "ABC"}; // 문제들
    int rand;  // rand를 클래스 레벨로 이동

    int life = 5; // 남은 목숨

    Label lbCorrect = new Label("", Label.CENTER); // 정답 단어
    Button btnScore = new Button("스코어");
    Button btnA = new Button("A");
    Button btnB = new Button("B");
    Button btnC = new Button("C");
    Button btnD = new Button("D");
    Button btnE = new Button("E");
    Button btnF = new Button("F");
    Button btnG = new Button("G");
    Button btnH = new Button("H");
    Button btnI = new Button("I");
    Button btnJ = new Button("J");
    Button btnK = new Button("K");
    Button btnL = new Button("L");
    Button btnM = new Button("M");
    Button btnN = new Button("N");
    Button btnO = new Button("O");
    Button btnP = new Button("P");
    Button btnQ = new Button("Q");
    Button btnR = new Button("R");
    Button btnS = new Button("S");
    Button btnT = new Button("T");
    Button btnU = new Button("U");
    Button btnV = new Button("V");
    Button btnW = new Button("W");
    Button btnX = new Button("X");
    Button btnY = new Button("Y");
    Button btnZ = new Button("Z");
    Button btnClear = new Button("초기화");

    Font font40 = new Font("SansSerif", Font.PLAIN, 40);
    Font font30 = new Font("SansSerif", Font.PLAIN, 30);
    Font font25 = new Font("SansSerif", Font.PLAIN, 25);
    Font font20 = new Font("SansSerif", Font.PLAIN, 20);
    Image img1 = Toolkit.getDefaultToolkit().getImage("UnderBar.png");

    HangOutTest() {
        super("HangMan");
        this.setSize(650, 500);
        init();
        start();
        this.setLocation(2700, 400);
        this.setVisible(true);
    }

    void init() {
        this.setLayout(null);
        this.add(lbCorrect);
        this.add(btnClear);
        this.add(btnA);
        this.add(btnB);
        this.add(btnC);
        this.add(btnD);
        this.add(btnE);
        this.add(btnF);
        this.add(btnG);
        this.add(btnH);
        this.add(btnI);
        this.add(btnJ);
        this.add(btnK);
        this.add(btnL);
        this.add(btnM);
        this.add(btnN);
        this.add(btnO);
        this.add(btnP);
        this.add(btnQ);
        this.add(btnR);
        this.add(btnS);
        this.add(btnT);
        this.add(btnU);
        this.add(btnV);
        this.add(btnW);
        this.add(btnX);
        this.add(btnY);
        this.add(btnZ);

        lbCorrect.setFont(font40);

        lbCorrect.setBounds(250, 50, 300, 50);
        btnClear.setBounds(50, 50, 40, 30);
        btnA.setBounds(50, 400, 30, 30);
        btnB.setBounds(90, 400, 30, 30);
        btnC.setBounds(130, 400, 30, 30);
        btnD.setBounds(170, 400, 30, 30);
        btnE.setBounds(210, 400, 30, 30);
        btnF.setBounds(250, 400, 30, 30);
        btnG.setBounds(290, 400, 30, 30);
        btnH.setBounds(330, 400, 30, 30);
        btnI.setBounds(370, 400, 30, 30);
        btnJ.setBounds(410, 400, 30, 30);
        btnK.setBounds(450, 400, 30, 30);
        btnL.setBounds(490, 400, 30, 30);
        btnM.setBounds(530, 400, 30, 30);
        btnN.setBounds(570, 400, 30, 30);
        btnO.setBounds(90, 440, 30, 30);
        btnP.setBounds(130, 440, 30, 30);
        btnQ.setBounds(170, 440, 30, 30);
        btnR.setBounds(210, 440, 30, 30);
        btnS.setBounds(250, 440, 30, 30);
        btnT.setBounds(290, 440, 30, 30);
        btnU.setBounds(330, 440, 30, 30);
        btnV.setBounds(370, 440, 30, 30);
        btnW.setBounds(410, 440, 30, 30);
        btnX.setBounds(450, 440, 30, 30);
        btnY.setBounds(490, 440, 30, 30);
        btnZ.setBounds(530, 440, 30, 30);
    }

    void start() {
        btnClear.addActionListener(this);
        btnA.addActionListener(this);
        btnB.addActionListener(this);
        btnC.addActionListener(this);
        btnD.addActionListener(this);
        btnE.addActionListener(this);
        btnF.addActionListener(this);
        btnG.addActionListener(this);
        btnH.addActionListener(this);
        btnI.addActionListener(this);
        btnJ.addActionListener(this);
        btnK.addActionListener(this);
        btnL.addActionListener(this);
        btnM.addActionListener(this);
        btnN.addActionListener(this);
        btnO.addActionListener(this);
        btnP.addActionListener(this);
        btnQ.addActionListener(this);
        btnR.addActionListener(this);
        btnS.addActionListener(this);
        btnT.addActionListener(this);
        btnU.addActionListener(this);
        btnV.addActionListener(this);
        btnW.addActionListener(this);
        btnX.addActionListener(this);
        btnY.addActionListener(this);
        btnZ.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(1);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnClear) {
            rand = (int) (Math.random() * word.length);  // btnClear 클릭할 때마다 rand 새롭게 생성
            enableAllButtons();

            sb.setLength(0); // sb 값 초기화
            for (int i = 0; i < word[rand].length(); i++) {
                sb.append("_ ");
            }
            lbCorrect.setText(sb.toString());
        }

        // 각 알파벳 버튼 클릭 시
        else {
            Button clickedButton = (Button) e.getSource();
            char letter = clickedButton.getLabel().charAt(0); // 클릭된 버튼의 알파벳

            // 단어의 알파벳과 맞으면 해당 위치에 알파벳 삽입
            for (int i = 0; i < word[rand].length(); i++) {
                if (word[rand].charAt(i) == letter) {
                    sb.setCharAt(i * 2, letter); // 해당 자리에 글자 삽입
                }
            }

            lbCorrect.setText(sb.toString()); // 화면에 업데이트
            clickedButton.setEnabled(false); // 클릭된 버튼 비활성화
        }
    }

    // 모든 버튼을 활성화하는 함수
    private void enableAllButtons() {
        btnA.setEnabled(true);
        btnB.setEnabled(true);
        btnC.setEnabled(true);
        btnD.setEnabled(true);
        btnE.setEnabled(true);
        btnF.setEnabled(true);
        btnG.setEnabled(true);
        btnH.setEnabled(true);
        btnI.setEnabled(true);
        btnJ.setEnabled(true);
        btnK.setEnabled(true);
        btnL.setEnabled(true);
        btnM.setEnabled(true);
        btnN.setEnabled(true);
        btnO.setEnabled(true);
        btnP.setEnabled(true);
        btnQ.setEnabled(true);
        btnR.setEnabled(true);
        btnS.setEnabled(true);
        btnT.setEnabled(true);
        btnU.setEnabled(true);
        btnV.setEnabled(true);
        btnW.setEnabled(true);
        btnX.setEnabled(true);
        btnY.setEnabled(true);
        btnZ.setEnabled(true);
    }
}
