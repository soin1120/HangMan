package MyProject2;

public class Study01 {

	public static void main(String[] args) {
	
		GameTitle gt = new GameTitle();

	}

}
