package MyProject2;

import java.util.Random;

public class imsi {
	public static void main(String[] args) {
		
	String[] world = {"BANANA","APPLE","GRAPE","ABC"}; //문제들 -> 메모장에서 가져와서 쓸것!
	int rand = (int)(Math.random()*world.length);// 배열의 길이만큼 랜덤수 생성
	//System.out.println("랜덤값: "+world[rand]);
	
	//world[rand] == world안에있는 랜덤 단어
	for(int i=0;i<world[rand].length();i++) {
		 System.out.print(world[rand].charAt(i));
		 if (i < world[rand].length() - 1) {
             System.out.print(", ");  // 마지막 문자가 아니면 ,를 추가
         }
	}
	
	
	
	
	int lengthWorld = world[rand].length(); //랜덤 단어의 길이
	//System.out.println("랜덤단어의 길이: "+lengthWorld);
	
	
	}
}
